﻿<?php
session_start();

// Połączenie z bazą danych
$mysqli = new mysqli("localhost", "root", "", "user_management");

if ($mysqli->connect_error) {
    die("Połączenie z bazą danych nie powiodło się: " . $mysqli->connect_error);
}

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Sprawdzamy, czy użytkownik istnieje
    $stmt = $mysqli->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id, $stored_password);
        $stmt->fetch();
        
        // Sprawdzamy, czy hasło jest poprawne
        if (password_verify($password, $stored_password)) {
            $_SESSION['user_id'] = $user_id;
            header("Location: index.html"); // Przenosi do strony głównej po zalogowaniu
            exit();
        } else {
            $error = "Błędne hasło!";
        }
    } else {
        $error = "Użytkownik nie znaleziony!";
    }

    $stmt->close();
}

$mysqli->close();
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="form-container">
        <h2>Logowanie</h2>
        <form action="login.php" method="post">
            <label for="username">Nazwa użytkownika:</label>
            <input type="text" name="username" required><br>

            <label for="password">Hasło:</label>
            <input type="password" name="password" required><br>

            <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>

            <button type="submit" name="login">Zaloguj się</button>
        </form>
        <p>Nie masz konta? <a href="register.php">Zarejestruj się</a></p>
    </div>
</body>
</html>



