$(document).ready(function () {
    // Obs�uguje klikni�cie przycisku
    $("#loadResults").click(function () {
        $.ajax({
            url: 'wyniki.txt', // �cie�ka do pliku na serwerze
            type: 'GET',
            success: function (data) {
                var lines = data.split("\n"); // Rozdzielamy dane na linie
                $("#results").empty(); // Czyszczenie poprzednich wynik�w

                // Dodajemy wyniki do listy
                lines.forEach(function (line) {
                    if (line.trim()) { // Sprawdzamy, czy linia nie jest pusta
                        $("#results").append("<li>" + line.trim() + "</li>");
                    }
                });
            },
            error: function () {
                alert("Wyst�pi� b��d podczas pobierania wynik�w.");
            }
        });
    });
});