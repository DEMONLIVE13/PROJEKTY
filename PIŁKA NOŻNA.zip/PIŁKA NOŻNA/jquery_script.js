$(document).ready(function () {
    $("#changeColor").click(function () {
        const randomColor = '#' + Math.floor(Math.random() * 16777215).toString(16);
        $("body").css("background-color", randomColor);
    });
});

$(document).ready(function () {
    var harmonogram = [];

    $("#dodaj-mecz").click(function () {
        var druzyna1 = $("#druzyna1").val();
        var druzyna2 = $("#druzyna2").val();
        var dataMeczu = $("#data-meczu").val();
        var godzinaMeczu = $("#godzina-meczu").val();

        if (druzyna1 && druzyna2 && dataMeczu && godzinaMeczu) {
            var mecz = druzyna1 + " vs " + druzyna2 + " - Data: " + dataMeczu + ", Godzina: " + godzinaMeczu;
            harmonogram.push(mecz);
            $("#harmonogram").append("<li>" + mecz + "</li>");
            $("#druzyna1").val('');
            $("#druzyna2").val('');
            $("#data-meczu").val('');
            $("#godzina-meczu").val('');
        }
    });

    // Funkcja zapisuj�ca harmonogram do pliku
    $("#zapisz-harmonogram").click(function () {
        if (harmonogram.length === 0) {
            alert("Brak mecz�w w harmonogramie.");
            return;
        }

        var harmonogramText = "Harmonogram Mecz�w:\n\n";
        harmonogram.forEach(function (mecz) {
            harmonogramText += mecz + "\n";
        });

        var blob = new Blob([harmonogramText], { type: 'text/plain;charset=utf-8' });
        saveAs(blob, "harmonogram.txt");
    });
});
// Funkcja resetuj�ca harmonogram
$("#resetuj").click(function () {
    harmonogram = []; // Wyczy�� tablic� harmonogramu
    $("#harmonogram").empty(); // Usu� wszystkie elementy z listy na stronie
    $("#druzyna1").val(''); // Wyczy�� pole dru�yny 1
    $("#druzyna2").val(''); // Wyczy�� pole dru�yny 2
    $("#data-meczu").val(''); // Wyczy�� pole daty meczu
    $("#godzina-meczu").val(''); // Wyczy�� pole godziny meczu
});

$(document).ready(function () {
    var $ball = $('.ball');
    var fieldWidth = $('.field').width();
    var fieldHeight = $('.field').height();
    var ballWidth = $ball.width();
    var ballHeight = $ball.height();

    var isMoving = false;  // Flaga do kontrolowania ruchu pi�ki
    var speedX = 2;  // Szybko�� ruchu pi�ki w poziomie
    var speedY = 2;  // Szybko�� ruchu pi�ki w pionie

    // Funkcja, kt�ra b�dzie porusza� pi�k�
    function moveBall() {
        if (!isMoving) return;

        var ballPosition = $ball.position();
        var newX = ballPosition.left + speedX;
        var newY = ballPosition.top + speedY;

        // Sprawdzamy, czy pi�ka nie wysz�a poza boisko w poziomie
        if (newX <= 0 || newX + ballWidth >= fieldWidth) {
            speedX = -speedX;
        }

        // Sprawdzamy, czy pi�ka nie wysz�a poza boisko w pionie
        if (newY <= 0 || newY + ballHeight >= fieldHeight) {
            speedY = -speedY;
        }

        // Ustawiamy now� pozycj� pi�ki
        $ball.css({
            left: newX,
            top: newY
        });

        // Funkcja porusza pi�k� co 10 ms
        setTimeout(moveBall, 10);
    }

    // Obs�uga klikni�cia na pi�k�
    $ball.click(function () {
        if (!isMoving) {
            isMoving = true;  // Rozpoczynamy ruch pi�ki po klikni�ciu
            moveBall();  // Uruchamiamy animacj�
        }
    });
});

$(document).ready(function () {
    // Obs�uguje klikni�cie na mecz
    $('.match').click(function () {
        // Ukrywamy wszystkie szczeg�y
        $('.details').hide();

        // Wybieramy mecz na podstawie atrybutu data-match i pokazujemy szczeg�y
        var matchId = $(this).data('match');
        $('#' + matchId).show();
    });
});
