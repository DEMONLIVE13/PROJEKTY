﻿<?php
// Połączenie z bazą danych
$mysqli = new mysqli('localhost', 'root', '', 'FormularzKontaktowy');

// Sprawdzenie połączenia z bazą danych
if ($mysqli->connect_error) {
    die("Błąd połączenia z bazą danych: " . $mysqli->connect_error);
}

// Sprawdzenie, czy żądanie zostało przesłane metodą POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Pobranie i walidacja danych z formularza
    $name = $mysqli->real_escape_string(trim($_POST['name']));
    $email = $mysqli->real_escape_string(trim($_POST['email']));
    $phone = $mysqli->real_escape_string(trim($_POST['phone']));
    $message = $mysqli->real_escape_string(trim($_POST['message']));

    // Wstawienie danych użytkownika do tabeli `Users`
    $insertUser = $mysqli->prepare("INSERT INTO Users (name, email, phone, message) VALUES (?, ?, ?, ?)");
    $insertUser->bind_param('ssss', $name, $email, $phone, $message);

    if ($insertUser->execute()) {
        $userId = $insertUser->insert_id; // Pobranie ID nowo dodanego użytkownika
        $insertUser->close();

        // Wyświetlenie zapisanych danych użytkownika
        echo "<h3>Dane zostały zapisane:</h3>";
        echo "<p><strong>Imię:</strong> " . htmlspecialchars($name) . "</p>";
        echo "<p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>";
        echo "<p><strong>Telefon:</strong> " . htmlspecialchars($phone) . "</p>";
        echo "<p><strong>Wiadomość:</strong> " . nl2br(htmlspecialchars($message)) . "</p>";

        // Obsługa przesłanego pliku
        if (isset($_FILES['file']) && $_FILES['file']['error'] == UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true); // Utwórz katalog, jeśli nie istnieje
            }

            $uploadFile = $uploadDir . basename($_FILES['file']['name']);
            if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadFile)) {
                // Zapisanie informacji o pliku w tabeli `Files`
                $insertFile = $mysqli->prepare("INSERT INTO Files (user_id, file_path) VALUES (?, ?)");
                $insertFile->bind_param('is', $userId, $uploadFile);

                if ($insertFile->execute()) {
                    echo "<br><strong>Plik został zapisany:</strong><br>";
                    echo "<p><strong>Nazwa pliku:</strong> " . htmlspecialchars($_FILES['file']['name']) . "</p>";
                    echo "<p><strong>Ścieżka pliku:</strong> " . htmlspecialchars($uploadFile) . "</p>";
                } else {
                    echo "Błąd podczas zapisywania informacji o pliku w bazie danych.";
                }
                $insertFile->close();
            } else {
                echo "Błąd przesyłania pliku. Upewnij się, że katalog 'uploads' ma odpowiednie uprawnienia.";
            }
        } else {
            echo "Dane zostały zapisane, ale plik nie został przesłany.";
        }
    } else {
        echo "Błąd podczas zapisywania danych użytkownika: " . $mysqli->error;
    }
} else {
    // Wyświetlenie wszystkich danych zapisanych w bazie danych
    $result = $mysqli->query("SELECT * FROM Users");

    if ($result->num_rows > 0) {
        echo "<h3>Wszystkie dane użytkowników:</h3>";
        while ($row = $result->fetch_assoc()) {
            echo "<div>";
            echo "<p><strong>Imię:</strong> " . htmlspecialchars($row['name']) . "</p>";
            echo "<p><strong>Email:</strong> " . htmlspecialchars($row['email']) . "</p>";
            echo "<p><strong>Telefon:</strong> " . htmlspecialchars($row['phone']) . "</p>";
            echo "<p><strong>Wiadomość:</strong> " . nl2br(htmlspecialchars($row['message'])) . "</p>";

            // Pobranie pliku powiązanego z użytkownikiem
            $fileResult = $mysqli->query("SELECT * FROM Files WHERE user_id = " . $row['id']);
            if ($fileResult->num_rows > 0) {
                while ($fileRow = $fileResult->fetch_assoc()) {
                    echo "<p><strong>Plik:</strong> " . htmlspecialchars($fileRow['file_path']) . "</p>";
                }
            } else {
                echo "<p><strong>Brak pliku dla tego użytkownika.</strong></p>";
            }

            echo "</div><hr>";
        }
    } else {
        echo "Brak zapisanych danych w bazie.";
    }
}

// Zamknięcie połączenia z bazą danych
$mysqli->close();
?>










