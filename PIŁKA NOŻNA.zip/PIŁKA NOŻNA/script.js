﻿// Pytania do quizu
const questions = [
    {
        question: "Który klub wygrał najwięcej razy Ligę Mistrzów?",
        options: ["Real Madrid", "AC Milan", "Bayern Monachium", "Barcelona"],
        answer: 0 // Indeks poprawnej odpowiedzi
    },
    {
        question: "Kto zdobył Złotą Piłkę w 2021 roku?",
        options: ["Lionel Messi", "Robert Lewandowski", "Cristiano Ronaldo", "Karim Benzema"],
        answer: 0
    },
    {
        question: "Ile drużyn gra w Premier League?",
        options: ["18", "20", "22", "24"],
        answer: 1
    },
    {
        question: "Która reprezentacja wygrała Mistrzostwa Świata 2018?",
        options: ["Niemcy", "Brazylia", "Francja", "Chorwacja"],
        answer: 2
    },
    {
        question: "Kto zdobył najwięcej bramek w historii reprezentacji Polski?",
        options: ["Robert Lewandowski", "Włodzimierz Lubański", "Grzegorz Lato", "Zbigniew Boniek"],
        answer: 0
    }
];

let currentQuestion = 0; // Aktualne pytanie
let score = 0; // Wynik użytkownika

const questionContainer = document.getElementById("question-container");
const resultContainer = document.getElementById("result-container");
const questionElement = document.querySelector(".question");
const optionsElement = document.querySelector(".options");
const scoreElement = document.getElementById("score");
const totalElement = document.getElementById("total");

// Funkcja do wyświetlenia pytania
function loadQuestion() {
    const current = questions[currentQuestion];
    questionElement.textContent = current.question;
    optionsElement.innerHTML = ""; // Wyczyść poprzednie opcje

    current.options.forEach((option, index) => {
        const button = document.createElement("button");
        button.textContent = option;
        button.classList.add("option");
        button.onclick = () => checkAnswer(index);
        optionsElement.appendChild(button);
    });
}

// Sprawdzenie odpowiedzi
function checkAnswer(selectedIndex) {
    const correctAnswer = questions[currentQuestion].answer;

    if (selectedIndex === correctAnswer) {
        score++;
        alert("Dobrze!");
    } else {
        alert(`Źle! Poprawna odpowiedź to: ${questions[currentQuestion].options[correctAnswer]}`);
    }

    currentQuestion++;
    if (currentQuestion < questions.length) {
        loadQuestion(); // Załaduj kolejne pytanie
    } else {
        showResults(); // Pokaż wynik
    }
}

// Pokaż wyniki
function showResults() {
    questionContainer.style.display = "none";
    resultContainer.style.display = "block";

    scoreElement.textContent = score;
    totalElement.textContent = questions.length;
}

// Restart quizu
function restartQuiz() {
    currentQuestion = 0;
    score = 0;
    questionContainer.style.display = "block";
    resultContainer.style.display = "none";
    loadQuestion();
}

// Inicjalizacja quizu
loadQuestion();
const quotes = [
    "Piłka nożna to gra błędów. Ten, kto popełni ich mniej, wygrywa. - Johan Cruyff",
    "Talent to nie wszystko. Trzeba jeszcze ciężko pracować. - Cristiano Ronaldo",
    "Ciężka praca bije talent, gdy talent nie pracuje ciężko. - Kevin Durant",
    "Wszystko, co wiem o moralności i obowiązkach, zawdzięczam piłce nożnej. - Albert Camus"
];

function showRandomQuote() {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    document.getElementById("quote").innerText = quotes[randomIndex];
}
setInterval(showRandomQuote, 5000);

    let goals = 0; // Liczba trafień
    let misses = 0; // Liczba pudł

    function simulatePenalty() {
        const result = Math.random() > 0.5 ? "Gol!" : "Pudło!";
        if (result === "Gol!") {
            goals++;
        } else {
            misses++;
        }

        // Aktualizuj wynik
        document.getElementById("penalty-result").innerText = result;
        document.getElementById("goals-count").innerText = `Gole: ${goals}`;
        document.getElementById("misses-count").innerText = `Pudła: ${misses}`;
}



