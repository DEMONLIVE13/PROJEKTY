﻿<?php


function dodajKomentarz($autor, $komentarz) {
    global $conn;

    // Zabezpieczanie danych przed SQL Injection
    $autor = $conn->real_escape_string($autor);
    $komentarz = $conn->real_escape_string($komentarz);

    // SQL do dodania komentarza
    $sql = "INSERT INTO komentarze (autor, komentarz) VALUES ('$autor', '$komentarz')";

    if ($conn->query($sql) === TRUE) {
        echo "Komentarz został dodany!";
    } else {
        echo "Błąd: " . $conn->error;
    }
}

// Funkcja do wyświetlania komentarzy
function wyswietlKomentarze() {
    global $conn;

    // SQL do pobrania wszystkich komentarzy
    $sql = "SELECT autor, komentarz, data FROM komentarze ORDER BY data DESC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Wyświetlamy każdy komentarz
        while($row = $result->fetch_assoc()) {
            echo "<div>";
            echo "<p><strong>" . htmlspecialchars($row['autor']) . ":</strong></p>";
            echo "<p>" . nl2br(htmlspecialchars($row['komentarz'])) . "</p>";
            echo "<p><em>Dodano: " . $row['data'] . "</em></p>";
            echo "</div><hr>";
        }
    } else {
        echo "Brak komentarzy.";
    }
}

// Sprawdzamy, czy formularz został wysłany
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['autor']) && isset($_POST['komentarz'])) {
    // Dodanie komentarza do bazy danych
    dodajKomentarz($_POST['autor'], $_POST['komentarz']);
    // Przekierowanie na tę samą stronę po wysłaniu formularza
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}




function getTopScorers($limit = 10) {
    global $conn;

    $sql = "SELECT player_name, goals FROM player_stats ORDER BY goals DESC LIMIT $limit";
    $result = $conn->query($sql);

    $top_scorers = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $top_scorers[] = [
                'player_name' => $row['player_name'],
                'goals' => $row['goals']
            ];
        }
    }
    return $top_scorers;
}
function getFixtures($season, $month) {
    global $conn;

    $sql = "SELECT home_team, away_team, match_date FROM matches
            WHERE YEAR(match_date) = '$season' AND MONTH(match_date) = '$month'";

    $result = $conn->query($sql);

    $fixtures = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $fixtures[] = [
                'home_team' => $row['home_team'],
                'away_team' => $row['away_team'],
                'match_date' => $row['match_date']
            ];
        }
    }
    return $fixtures;
}
?>
