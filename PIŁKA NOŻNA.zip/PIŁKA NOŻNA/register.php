﻿<?php
// Połączenie z bazą danych
$mysqli = new mysqli("localhost", "root", "", "user_management");

if ($mysqli->connect_error) {
    die("Połączenie z bazą danych nie powiodło się: " . $mysqli->connect_error);
}

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Sprawdzamy, czy hasła się zgadzają
    if ($password !== $confirm_password) {
        $error = "Hasła muszą być identyczne!";
    } else {
        // Szyfrowanie hasła
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Dodanie użytkownika do bazy danych
        $stmt = $mysqli->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashed_password);
        
        if ($stmt->execute()) {
            // Przenosimy do strony logowania
            header("Location: login.php");
            exit();
        } else {
            $error = "Błąd rejestracji: " . $stmt->error;
        }

        $stmt->close();
    }
}

$mysqli->close();
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejestracja</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="form-container">
        <h2>Rejestracja</h2>
        <form action="register.php" method="post">
            <label for="username">Nazwa użytkownika:</label>
            <input type="text" name="username" required><br>

            <label for="email">Email:</label>
            <input type="email" name="email" required><br>

            <label for="password">Hasło:</label>
            <input type="password" name="password" required><br>

            <label for="confirm_password">Potwierdź hasło:</label>
            <input type="password" name="confirm_password" required><br>

            <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>

            <button type="submit" name="register">Zarejestruj się</button>
        </form>
        <p>Masz już konto? <a href="login.php">Zaloguj się</a></p>
    </div>
</body>
</html>


