﻿<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
   
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piłka Nożna - Najlepszy strzelcy i komentarze</title>
    <link rel="stylesheet" href="style.css">

    <style>
    label,textarea {
            color: black;
            text-align:center;
        } 
       

    </style>



</head>
<body>
    <header>
        <h3>Piłka Nożna</h3>
        <nav>
            <ul>
                <li><a href="index.html">Strona Główna</a></li>
                <li><a href="podstrona1.html">Historia</a></li>
                <li><a href="podstrona2.html">Zasady Gry</a></li>
                <li><a href="podstrona3.html">Słynni Zawodnicy</a></li>
                <li><a href="podstrona4.html">Najnowsze Wyniki i Kup Bilety</a></li>
                <li><a href="podstrona5.html">Kontakt</a></li>
                <li><a href="index.php">Najlepsi i komentarze</a></li>
                <li><a href="register.php">Zarejestruj się</a></li>
            </ul>
        </nav>
<?php
include 'db.php';
include 'functions.php';

// Wyświetlanie najlepszych strzelców
$top_scorers = getTopScorers();
echo "<h3>Najlepsi Strzelcy</h3>";
foreach ($top_scorers as $scorer) {
    echo "<br>" . $scorer['player_name'] . " - " . $scorer['goals'] . " goli <br>";
    
}
 

// Wyświetlanie terminarza na grudzień 2024
$fixtures = getFixtures(2024, 12);
echo "<br><h3>Mecze w Grudniu 2024</h3><ul>";
foreach ($fixtures as $fixture) {
    echo "<li>" . $fixture['home_team'] . " vs " . $fixture['away_team'] . " - " . $fixture['match_date'] . "</li>";
}
echo "</ul>";

// Dodawanie komentarzy do meczu
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $message = dodajkomentarz($_POST['autor'], $_POST['komentarz']);
    echo $message;
}
?>

 <h2>Dodaj komentarz do meczu</h2>

    <!-- Formularz HTML do dodawania komentarza -->
    <form action="" method="post">
        <label for="autor"> autor:</label><br>
        <input type="text" id="autor" name="autor" required><br><br>

        <label for="komentarz">Twój komentarz:</label><br>
        <textarea id="komentarz" name="komentarz" rows="4" cols="50" required></textarea><br><br>

        <input type="submit" value="Dodaj komentarz">
    </form>

    <hr>

    <h2>Komentarze:</h2>

    <?php
        // Wyświetlanie wszystkich komentarzy
        wyswietlKomentarze();
    ?>

</body>
<footer>
        <p>&copy; Szymon Głogowski 2024 Piłka Nożna.</p>
    </footer>

</html>
