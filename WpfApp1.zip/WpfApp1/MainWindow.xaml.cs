﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace TrainScheduleApp
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public ObservableCollection<Train> Trains { get; set; } = new();
        public ObservableCollection<Train> FilteredTrains { get; set; } = new();
        private const string JsonPath = "trains.json";
        private string _filterText = "";
        private bool _isDarkMode = false;

        public event PropertyChangedEventHandler PropertyChanged;

        public string FilterText
        {
            get => _filterText;
            set
            {
                if (_filterText != value)
                {
                    _filterText = value;
                    FilterTrains();
                    OnPropertyChanged(nameof(FilterText));
                }
            }
        }

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            LoadTrains();
            FilterTrains();
            StartClock();
            SetLoginVisibility(true);
            StartScrollingTextAnimation();
        }

        private void LoadTrains()
        {
            try
            {
                if (File.Exists(JsonPath))
                {
                    var json = File.ReadAllText(JsonPath);
                    var loadedTrains = JsonSerializer.Deserialize<ObservableCollection<Train>>(json);
                    if (loadedTrains != null)
                        Trains = loadedTrains;
                }
                else
                {
                    // Przykładowe dane gdy plik JSON nie istnieje
                    Trains = new ObservableCollection<Train>
                    {
                        new Train
                        {
                            TrainNumber = "IC123",
                            DepartureStation = "Warszawa",
                            ArrivalStation = "Kraków",
                            DepartureTime = DateTime.Now.AddHours(1),
                            ArrivalTime = DateTime.Now.AddHours(3),
                            DelayMinutes = 0,
                            Route = "Warszawa - Kraków",
                            Notes = "Brak opóźnień",
                            IsFavorite = true,
                            DeparturePlatform = 1
                        }
                    };
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Błąd ładowania danych: " + ex.Message);
                Trains = new ObservableCollection<Train>();
            }
        }

        private void FilterTrains()
        {
            FilteredTrains.Clear();
            foreach (var train in Trains)
            {
                if (string.IsNullOrWhiteSpace(FilterText) ||
                    (train.ArrivalStation?.IndexOf(FilterText, StringComparison.OrdinalIgnoreCase) >= 0) ||
                    (train.Route?.IndexOf(FilterText, StringComparison.OrdinalIgnoreCase) >= 0))
                {
                    FilteredTrains.Add(train);
                }
            }
            OnPropertyChanged(nameof(FilteredTrains));
        }

        private void StartClock()
        {
            DispatcherTimer timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += (s, e) => { ClockText.Text = DateTime.Now.ToString("HH:mm:ss"); };
            timer.Start();
        }

        private void SetLoginVisibility(bool showLogin)
        {
            UsernameBox.Visibility = showLogin ? Visibility.Visible : Visibility.Collapsed;
            PasswordBox.Visibility = showLogin ? Visibility.Visible : Visibility.Collapsed;
            LoginButton.Visibility = showLogin ? Visibility.Visible : Visibility.Collapsed;

            TrainList.Visibility = !showLogin ? Visibility.Visible : Visibility.Collapsed;
            ClockText.Visibility = !showLogin ? Visibility.Visible : Visibility.Collapsed;
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            if (UsernameBox.Text == "admin" && PasswordBox.Password == "1234")
            {
                SetLoginVisibility(false);
            }
            else
            {
                MessageBox.Show("Nieprawidłowe dane logowania , poprawny login to admin a hasło to 1234");
            }
        }

        private void AddTrain_Click(object sender, RoutedEventArgs e)
        {
            var newTrain = new Train
            {
                TrainNumber = "Nowy",
                DepartureStation = "Nowa Stacja",
                ArrivalStation = "Cel",
                DepartureTime = DateTime.Now.AddMinutes(5),
                ArrivalTime = DateTime.Now.AddMinutes(60),
                DelayMinutes = 0,
                Route = "Trasa nowa",
                Notes = "",
                IsFavorite = false,
                DeparturePlatform = 0
            };
            Trains.Add(newTrain);
            FilterTrains();
        }

        private void DeleteTrain_Click(object sender, RoutedEventArgs e)
        {
            if (TrainList.SelectedItem is Train selected)
            {
                Trains.Remove(selected);
                FilterTrains();
            }
        }

        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                string json = JsonSerializer.Serialize(Trains, options);
                File.WriteAllText(JsonPath, json);
                MessageBox.Show("Dane zostały zapisane.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Błąd zapisu danych: " + ex.Message);
            }
        }

        private void ToggleTheme_Click(object sender, RoutedEventArgs e)
        {
            _isDarkMode = !_isDarkMode;

            if (_isDarkMode)
            {
                Resources["BackgroundBrush"] = new SolidColorBrush(Color.FromRgb(30, 30, 30)); // tło okna
                Resources["ForegroundBrush"] = new SolidColorBrush(Colors.White); // tekst ogólny
                Resources["PanelBackgroundBrush"] = new SolidColorBrush(Color.FromRgb(45, 45, 48)); // tło paneli
                Resources["TextForegroundBrush"] = new SolidColorBrush(Colors.Red); // czerwony tekst
                Resources["TopPanelBackgroundBrush"] = new SolidColorBrush(Color.FromRgb(70, 70, 70)); // jaśniejszy pasek u góry
            }
            else
            {
                Resources["BackgroundBrush"] = new SolidColorBrush(Colors.White);
                Resources["ForegroundBrush"] = new SolidColorBrush(Colors.Black);
                Resources["PanelBackgroundBrush"] = new SolidColorBrush(Color.FromRgb(240, 240, 240));
                Resources["TextForegroundBrush"] = new SolidColorBrush(Color.FromRgb(30, 30, 30));
                Resources["TopPanelBackgroundBrush"] = new SolidColorBrush(Color.FromRgb(245, 245, 245));
            }
        }

        private void StartScrollingTextAnimation()
        {
            if (ScrollingText.ActualWidth == 0)
            {
                ScrollingText.Loaded += (s, e) => StartScrollingTextAnimation();
                return;
            }

            double canvasWidth = ((Canvas)ScrollingText.Parent).ActualWidth;
            double from = canvasWidth;
            double to = -ScrollingText.ActualWidth;

            Canvas.SetLeft(ScrollingText, from);

            var animation = new DoubleAnimation
            {
                From = from,
                To = to,
                Duration = TimeSpan.FromSeconds(10),
                RepeatBehavior = RepeatBehavior.Forever,
                EasingFunction = null
            };

            ScrollingText.BeginAnimation(Canvas.LeftProperty, animation);
        }

        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public class Train : INotifyPropertyChanged
    {
        private string _trainNumber;
        private string _departureStation;
        private string _arrivalStation;
        private DateTime _departureTime;
        private DateTime _arrivalTime;
        private int _delayMinutes;
        private string _route;
        private string _notes;
        private bool _isFavorite;
        private int _departurePlatform;

        public string TrainNumber
        {
            get => _trainNumber;
            set { if (_trainNumber != value) { _trainNumber = value; OnPropertyChanged(); } }
        }
        public string DepartureStation
        {
            get => _departureStation;
            set { if (_departureStation != value) { _departureStation = value; OnPropertyChanged(); } }
        }
        public string ArrivalStation
        {
            get => _arrivalStation;
            set { if (_arrivalStation != value) { _arrivalStation = value; OnPropertyChanged(); } }
        }
        public DateTime DepartureTime
        {
            get => _departureTime;
            set { if (_departureTime != value) { _departureTime = value; OnPropertyChanged(); } }
        }
        public DateTime ArrivalTime
        {
            get => _arrivalTime;
            set { if (_arrivalTime != value) { _arrivalTime = value; OnPropertyChanged(); } }
        }
        public int DelayMinutes
        {
            get => _delayMinutes;
            set { if (_delayMinutes != value) { _delayMinutes = value; OnPropertyChanged(); } }
        }
        public string Route
        {
            get => _route;
            set { if (_route != value) { _route = value; OnPropertyChanged(); } }
        }
        public string Notes
        {
            get => _notes;
            set { if (_notes != value) { _notes = value; OnPropertyChanged(); } }
        }
        public bool IsFavorite
        {
            get => _isFavorite;
            set { if (_isFavorite != value) { _isFavorite = value; OnPropertyChanged(); } }
        }

        [JsonPropertyName("DeparturePlatform")]
        public int DeparturePlatform
        {
            get => _departurePlatform;
            set { if (_departurePlatform != value) { _departurePlatform = value; OnPropertyChanged(); } }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
